/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nwpriorityqueue;

/**
 *
 * @author Jason
 */
public class Test 
{
    public static void main(String [] args)
    {
        IntegerComparator comp = new IntegerComparator();
        NwPriorityQueue<Integer> pq = new NwPriorityQueue<Integer>(comp);
        
        

        pq.add(8);
        pq.add(6);
        pq.add(29);
        pq.add(28);
        pq.add(39);
        pq.add(37);

        pq.add(18);      
       System.out.println(pq.peek());

    
    }

        

    
}
