/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nwpriorityqueue;

import java.util.AbstractQueue;
import java.util.Comparator;
import java.util.Iterator;

/**
 *
 * @author Jason
 */
public class NwPriorityQueue<E extends Comparable> extends AbstractQueue<E>
{   
    private Node<E> root = null;
    private int size = 0;
    private Comparator<E> comparator;
    
    
    public NwPriorityQueue(Comparator<E> comp)
    {
        this.comparator = comp;
    }
    
    public NwPriorityQueue()
    {
        root = null;
        comparator = null;
    }
    
        
        
    @Override
    public Iterator<E> iterator()
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int size()
    {
        return size;
    }

    @Override
    public boolean offer(E e)
    {
            if(root == null)
            root = new Node<E>(e);
        else
        {
            findAndAdd(root, e);
        }
        
        arrangeQueue(root);
        this.size++;
        return true;
    }

    private boolean findAndAdd(Node<E> localRoot, E e)
    {   
        if(localRoot.left == null)
        {
            localRoot.left = new Node<E>(e);
            return true;
        }
        else if (localRoot.right == null)
        {
            localRoot.right = new Node<E>(e);
            return true;
        }
        else
        {
            if(localRoot.left.left == null || localRoot.left.right == null)
                return findAndAdd(localRoot.left, e);
            else if(localRoot.right.left == null || localRoot.right.right == null)
                return findAndAdd(localRoot.right, e);
            else
                return findAndAdd(localRoot.left, e);                
        }
       
    }
    
    
    

    private void arrangeQueue(Node<E> localRoot)
    {
        if(localRoot.right != null)
        {
            if (comparator.compare(localRoot.data, localRoot.right.data) > 0 )
            {                
                E temp = localRoot.right.data;
                localRoot.right.data = localRoot.data;
                localRoot.data = temp;
            }
            arrangeQueue(localRoot.right);
        }
        else if(localRoot.left != null)
        {
            if (comparator.compare(localRoot.data, localRoot.left.data) > 0 )
            {
                E temp = localRoot.left.data;
                localRoot.left.data = localRoot.data;
                localRoot.data = temp; 
            }
            arrangeQueue(localRoot.left);
        }

        
    }
    @Override
    public E poll()
    {
        E temp = root.data;
        
        root = removeRec(root);
        arrangeQueue(root);
        
        
        
        return temp;
    }

    public Node<E> removeRec(Node<E> localRoot)
    {

        if(localRoot.left == null && localRoot.right == null)
            return localRoot;
        else
        {
            return removeRec(localRoot.right);
        }
            
    
    
    }
        
        
        
    @Override
    public E peek()
    {
        return root.data;
    }
 
    
    
    
    
      
    private class Node<E>
    {
        private Node<E> left = null;
        private Node<E> right = null;
        private E data = null;
        
        
        private Node(Node<E> nLeft, Node<E> nRight, E nDAta)
        {
            left = nLeft;
            right = nRight;
            data = nDAta;
        }
        
        private Node(E nDAta)
        {
            data = nDAta;
        }
        private Node()
        {
            this(null, null, null);
        }
        
    }
    
    
    
    
    
}
