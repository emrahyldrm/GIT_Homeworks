/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nwpriorityqueue;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jason
 */
public class PriorityQueueTest {
    
    public PriorityQueueTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of add method, of class PriorityQueue.
     */
    @Test
    public void testAdd1()
    {
       System.out.println("Test size function, expected size 3 ");
       Queue<Integer> temp = new PriorityQueue<Integer>();

       temp.add(4565);       
       assertEquals(1, temp.size());           
    }

        @Test
    public void testAdd2()
    {
       System.out.println("NULL POINTER EXCEPTION TEST ");
       Queue<Integer> temp =null;
       try
       {
            System.out.println(temp.peek().toString());
       }catch (Exception e)
       {
           System.err.println(e.toString());
         if(!(e instanceof NullPointerException))
              fail("Expected exception was NULL POINTER EXCEPTION");
               
       } 
            
    }

    
        @Test
    public void testAdd3()
    {
       System.out.println("Add method elemet equality test");
       Queue<Integer> temp = new PriorityQueue<>();
      
        temp.add(23);
        temp.add(12);    
        
        int expected = temp.peek();
        assertEquals(12, expected);
    }

    
        @Test
    public void testAdd4()
    {
       System.out.println("Add element control ");
       Queue<Integer> temp =new PriorityQueue<>();
      
        temp.add(233);
        temp.add(123); 
        boolean expected = temp.contains(123);
        
        assertEquals(true, expected);
    }

    
 /*****************************************************************************/  
    
        @Test
    public void testOffer1()
    {
       System.out.println("expected size 3 ");
       Queue<Integer> temp = new PriorityQueue<Integer>();

       temp.add(4565);       
       assertEquals(1, temp.size());           
    }

        @Test
    public void testOffer2()
    {
       System.out.println("NULL POINTER TEST ");
       Queue<Integer> temp =null;
       try
       {
            System.out.println(temp.peek().toString());
       }catch (Exception e)
       {
           System.err.println(e.toString());
         if(!(e instanceof NullPointerException))
              fail("Expected exception was NULL POINTER EXCEPTION");
               
       } 
            
    }

    
        @Test
    public void testOffer3()
    {
       System.out.println("Add elemet equality");
       Queue<Integer> temp = new PriorityQueue<>();
      
        temp.add(23);
        temp.add(12);    
        
        int expected = temp.peek();
        assertEquals(12, expected);
    }

    
        @Test
    public void testOffer4()
    {
       System.out.println("Add element control ");
       Queue<Integer> temp =new PriorityQueue<>();
      
        temp.add(233);
        temp.add(123); 
        boolean expected = temp.contains(123);
        
        assertEquals(true, expected);
    }

    
    /**************************************************************************/

    /**
     * Test of remove method, of class PriorityQueue.
     */
    @Test
    public void testRemove_0args1()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.remove();
//      assertEquals(55, obj1.peek());
        System.out.println("after remove method  different peek value\n");       
        
    } 

    
    public void testRemove_0args2()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.remove(2);
        assertNotSame(25, obj1.peek());
        System.out.println("after remove method  size  equality test, passed\n");       
       
    }  

        
    public void testRemove_0args3()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        Queue<Integer> obj2 = null;
        
        try
        {
            obj1.add(55);
            obj1.add(25);
            obj2.add(55);
            obj1.remove(obj2);
        }
        catch(Exception e)
        {
            if(!(e instanceof NullPointerException))
                fail();
        }
            System.out.println("NullPointerException has been caught, passed\n");             
   }    
            
            
    public void testRemove_0args4()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.remove();
        assertEquals(false, obj1.contains(55));   
        System.out.println("after remove method  element contains not equality test, passed\n");     

    }     
    
    /**************************************************************************/
  
    @Test
    public void testPoll1()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.poll();
        System.out.println("after poll method  different value\n");       
        
    } 

    
    public void testPoll2()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.poll();
        assertNotSame(25, obj1.peek());
        System.out.println("after poll method  size  equality test, passed\n");       
       
    }  

        
    public void testPol3()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        try
        {
            obj1.add(55);
            obj1.add(25);
            obj1.poll();
        }
        catch(Exception e)
        {
            if(!(e instanceof NullPointerException))
                fail();
        }
            System.out.println("NullPointerException has been caught, passed\n");             
   }    
            
            
    public void testPoll4()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.poll();
        assertEquals(false, obj1.contains(55));   
        System.out.println("after poll method  element contains not equality test, passed\n");     

    }      
    
    
   
    
    /*************************************************************************/
    /**
     * Test of peek method, of class PriorityQueue.
     */
  
    @Test
    public void testPeek1()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.peek();
        System.out.println("after peek method  different value\n");       
        
    } 

    
    public void testPeek2()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.add(55);
        obj1.peek();
        assertNotSame(25, obj1.peek());
        System.out.println("after peek method  size  equality test, passed\n");       
       
    }  

        
    public void testPeek3()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        try
        {
            obj1.add(55);
            obj1.add(25);
            obj1.peek();
        }
        catch(Exception e)
        {
            if(!(e instanceof NullPointerException))
                fail();
        }
            System.out.println("NullPointerException has been caught, passed\n");             
   }    
            
            
    public void testPeek4()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(25);
        obj1.peek();
        assertEquals(false, obj1.contains(55));   
        System.out.println("after remove method  element contains not equality test, passed\n");     

    }      
    

    /**
     * Test of size method, of class PriorityQueue.
     */
    @Test
    public void testSize1()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(55);
        obj1.add(56);

        assertEquals(obj1.size(),2);
        System.out.println("size method equality test after adding , passed\n");                     

    }
    
    
    
        @Test
    public void testSize2()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        Queue<Integer> obj2 = new PriorityQueue<>();   
        
        obj1.add(55);
        obj1.add(56);
        obj2.add(550);
        obj2.add(55);
        
        assertEquals(obj1.size(), obj2.size());
        System.out.println("size method equality test between 2 lists after adding , passed\n");   
    }
    
    
    
    
        @Test
    public void testSize3()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        assertEquals(obj1.size(),0);
        System.out.println("size method equality  0 test without adding , passed\n");   
    }
       
    
    
    
        @Test
    public void testSize4()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();        
        obj1.add(55);
        obj1.add(56);
        obj1.poll();
        
        assertEquals(obj1.size(), 1);
        System.out.println("size method equality test after add and remove , passed\n");   
        
    }  
    /**************************************************************************/

    /**
     * Test of isEmpty method, of class PriorityQueue.
     */
    @Test
    public void testIsEmpty1()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        Queue<Integer> obj2 = new PriorityQueue<>();
        
        obj1.add(34);
        obj2.add(54);
        
        assertEquals(obj2.isEmpty(), obj1.isEmpty()); 
        System.out.println("isEmpty method equality between two lists test, passed\n");       
    }    
    
    
    
        @Test
    public void testIsEmpty2()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        Queue<Integer> obj2 = new PriorityQueue<>();
        
        obj1.add(34);
        assertNotSame(obj2.isEmpty(), obj1.isEmpty());   
        System.out.println("isEmpty method not equality between two lists test, passed\n");    
    }

    
    
    
        @Test
    public void testIsEmpty3()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        obj1.add(34);
        assertEquals(false, obj1.isEmpty());   
        System.out.println("isEmpty method not equality test, passed\n");     
    }
    
    
    
    
        @Test
    public void testIsEmpty4()
    {
        Queue<Integer> obj1 = new PriorityQueue<>();
        
        assertEquals(true, obj1.isEmpty());    
        System.out.println("isEmpty method equality test, passed\n");            
    }
    
    
    /**************************************************************************/

    /**
     * Test of contains method, of class PriorityQueue.
     */
    @Test
    public void testContains()
    {

        Queue<Integer> linked = new PriorityQueue<>();
        Queue<Integer> array = new PriorityQueue<>();
        
        linked.add(53);
        linked.add(540);
        array.addAll(linked);
        
        assertEquals(true, array.contains(53));
        System.out.println("Contains search element test, passed\n");
        
    }

    
    @Test
    public void testContains1()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Queue<Integer> array = new PriorityQueue<>();
        
        linked.add(53);
        linked.add(540);
        array.addAll(linked);
        
        assertEquals(false, array.contains(null));
        System.out.println("Contains search null element test(false), passed\n");
        
    }
    
    
    
    
    
        @Test
    public void testContains2()
    {
        Queue<Integer> linked = null;
        Queue<Integer> array = null;
        try
        {
        linked.add(53);
        linked.add(540);
        array.addAll(linked);
        }
        catch(NullPointerException e)
        {
            System.out.println("Contains search null pointer test, passed\n");
        }
    }
    
       
    
    
    /**************************************************************************/
    /**
     * Test of iterator method, of class PriorityQueue.
     */
    @Test
    public void testIterator1()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Iterator<Integer> iter = linked.iterator();
        
        assertNotSame(null, iter);   
        System.out.println("iterator method  not null equality test, passed\n");             
    }
                
 
    
    @Test
    public void testIterator2()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Iterator<Integer> iter = linked.iterator();
        
        linked.add(5);
        linked.add(52);
        linked.add(33);
        linked.add(3);
        assertNotSame(false, iter.hasNext());        
        System.out.println("iterator method  before adding equality test, passed\n");             
    }
    
             
    @Test
    public void testIterator3()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        
        linked.add(5);
        linked.add(52);
        linked.add(33);
        linked.add(3);
        Iterator<Integer> iter = linked.iterator();

        int a = iter.next();
        assertEquals(3, a);  
        System.out.println("iterator method  after adding equality test, passed\n");                     
    }    
    
    
    @Test
    public void testIterator4()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Iterator<Integer> iter = linked.iterator();
        try
        {
            linked.add(5);
            linked.add(52);
            linked.add(33);
            linked.add(3);


            int a = iter.next();
        }catch(Exception e)
        {
            if(!(e instanceof ConcurrentModificationException))
                    fail();
        }
        System.out.println("ConcurrentModificationExp has been caught, passed\n");             

    }    
    
    
    /**************************************************************************/
    /**
     * Test of toArray method, of class PriorityQueue.
     */
    @Test
    public void testToArray_0args()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Integer [] array = new Integer[20];
        
        try
        {
           linked.add(455);
           linked.add(222);
           linked.add(12);
           linked.add(21);
           linked.add(44355);
           linked.add(22432);

           array = (Integer [])linked.toArray();
        }
        catch(Exception e)
        {
           if(!(e instanceof ClassCastException))
                fail();
        }
        System.out.println("ClassCastException has been caught, passed");
    }             
    
    
    
    
    @Test
    public void testToArray_0args2()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Object [] array = new Object[20];
        
  
        linked.add(455);
        linked.add(222);
        linked.add(12);
        linked.add(21);
        linked.add(44355);
        linked.add(22432);

        array = linked.toArray();
        assertEquals(array.length, 6);
        System.out.println("compare new array size and to array return value size test, passed"); 
    }     
                 
        
    
    @Test
    public void testToArray_0args3()
    {
        Queue<Integer> linked = null;
        Integer [] array = new Integer[20];
        
        try
        {
           array = (Integer [])linked.toArray();
        }
        catch(Exception e)
        {
           if(!(e instanceof NullPointerException))
                fail();
        }
        System.out.println("NullPointerException has been caught, passed");
    }            
        
    
    @Test
    public void testToArray_0args4()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Integer [] array = new Integer[20];
        
  
        linked.add(455);
        linked.add(222);
        linked.add(12);
        linked.add(21);
        linked.add(44355);
        linked.add(22432);
        
        array = linked.toArray(array);
        int a = array[0];
        assertEquals(12, a);
        System.out.println("compare new array's element is expected test, passed"); 
    }            
        
    
    
    /**************************************************************************/
    
    

    /**
     * Test of toArray method, of class PriorityQueue.
     */
    @Test
    public void testToArray_GenericType()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Integer [] array = new Integer[20];
        
        try
        {
           linked.add(455);
           linked.add(222);
           linked.add(12);
           linked.add(21);
           linked.add(44355);
           linked.add(22432);

           array = (Integer [])linked.toArray(array);
        }
        catch(Exception e)
        {
           if((e instanceof ClassCastException))
                fail();
        }
        System.out.println("ClassCastException has been caught, passed");

    }     

            
            
            
    @Test
    public void testToArray_GenericType2()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Integer [] array = new Integer[20];
        
  
        linked.add(455);
        linked.add(222);
        linked.add(12);
        linked.add(21);
        linked.add(44355);
        linked.add(22432);
        
        array = linked.toArray(array);
        int a = array[0];
        assertEquals(12, a);
        System.out.println("compare new array's element is expected test, passed"); 
    }               
            
            
    @Test
    public void testToArray_GenericType3()
    {
        Queue<Integer> linked = new PriorityQueue<>();
        Object [] array = new Object[20];
        
  
        linked.add(455);
        linked.add(222);
        linked.add(12);
        linked.add(21);
        linked.add(44355);
        linked.add(22432);

        int expected=0;
        array = linked.toArray(array);
        for (int i = 0; i < array.length; i++) {
            if(array[i] != null)
                expected++;
        }
        assertEquals(expected, 6);
        System.out.println("compare new array size and to array return value size test, passed"); 
    }              
            
    @Test
    public void testToArray_GenericType4()            
    {
        Queue<Integer> linked = null;
        Integer [] array = new Integer[20];
        
        try
        {
           array = (Integer [])linked.toArray(array);
        }
        catch(Exception e)
        {
           if(!(e instanceof NullPointerException))
                fail();
        }
        System.out.println("NullPointerException has been caught, passed");
    } 
                           
            
            
/******************************************************************************/            

    /**
     * Test of containsAll method, of class PriorityQueue.
     */
    @Test
    public void containsAllTest1()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(34);
        linked.add(45);
        array.add(44);
        
        assertEquals(false, array.containsAll(linked));
        System.out.println("ContainsAll search other collection elemets test(false), passed\n");     
    }
    
    
    @Test
    public void containsAllTest2()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(34);
        linked.add(45);
        array.addAll(linked);
        
        assertEquals(true, array.containsAll(linked));
        System.out.println("ContainsAll search other collection elemets test(true), passed\n");          
    }
    
    
    
    
    /**************************************************************************/

    
        
    @Test
    public void addAllTest1()
    {
        System.out.print("Add All method test other collection");
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add((45));
        linked.add((451));
        linked.add((452));
        linked.add((425));
        
        array.addAll(linked);
        array.add(1234);
        
        int expectedSize = array.size();
        assertEquals(linked.size()+1, expectedSize);
    }
    
    
    
    
    
    @Test
    public void addAllTest2()
    {
        System.out.print("Add All method test other collection");
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        array.add((45));
        array.add((451));
        array.add((452));
        array.add((425));
        
        linked.addAll(array);
        linked.add(1234);
        
        int expectedSize = linked.size();
        assertEquals(array.size()+1, expectedSize);
    }
    
    
    @Test
    public void addAllTest3()
    {
        Queue<Integer> array = null;
        
        try
        {
            array.add(54);
        }catch (NullPointerException e)
        {
            System.out.println("Null Poınter exception has been caught");
        }
    }
    
    
    @Test
    public void addAllTest4()
    {        
        System.out.print("Add All method test other collection element equality test");
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        array.add((45));
        array.add((451));
        array.add((452));
        array.add((425));
        
        linked.addAll(array);
        linked.add(1234);
        
        int expected = linked.peek();
        assertEquals(45, expected);
    }
       

    /**
     * Test of removeAll method, of class PriorityQueue.
     */

    @Test
    public void removeAllMethodTest1()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        linked.add(55);
        linked.removeAll(array);
        assertNotSame(0, linked.size());          
        System.out.println("after removeAll method  size  equality test, passed\n");       
    }  
    
    @Test
    public void removeAllMethodTest2()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        array.add(55);
        linked.removeAll(array);
        assertNotSame(true, linked.contains(55));             
        System.out.println("after removeAll method  element contains not  equality test, passed\n");     
    }  
    
    
    @Test
    public void removeAllMethodTest3()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        array.add(12);
        linked.removeAll(array);
        assertEquals(true, linked.contains(55));   
        System.out.println("after removeAll method  element contains equality test, passed\n");     

    }      
    
    @Test
    public void removeAllMethodTest4()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = null;
        
        try
        {
            linked.add(55);
            linked.add(25);
            array.add(55);
            linked.removeAll(array);
        }
        catch(Exception e)
        {
            if(!(e instanceof NullPointerException))
                fail();
        }
            System.out.println("NullPointerException has been caught, passed\n");             
   }       
    



    /**
     * Test of retainAll method, of class PriorityQueue.
     */
     @Test
    public void retainAllMethodTest1()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        linked.add(55);
        linked.retainAll(array);
        assertEquals(0, linked.size());  
        System.out.println("after retainall method size equality test, passed\n");                     
    }  
    
    @Test
    public void retainAllMethodTest2()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        array.add(55);
        linked.retainAll(array);
        assertNotSame(false, linked.contains(55));       
        System.out.println("after retainall method  elements not equality test, passed\n");                     
    }  
    
    
    @Test
    public void retainAllMethodTest3()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = new PriorityQueue();
        
        linked.add(55);
        linked.add(25);
        array.add(12);
        linked.retainAll(array);
        assertEquals(false, linked.contains(55));   
        System.out.println("after retainall method  elements equality test, passed\n");                     
        
    }      
    
    @Test
    public void retainAllMethodTest4()
    {
        Queue<Integer> linked = new PriorityQueue();
        Queue<Integer> array = null;
        
        try
        {
            linked.add(55);
            linked.add(25);
            array.add(55);
            linked.retainAll(array);
        }
        catch(Exception e)
        {
            if(!(e instanceof NullPointerException))
                fail();
        }
        System.err.println("Nullpointerexp has been caught, passed");
    }      

    /**
     * Test of clear method, of class PriorityQueue.
     */
   @Test
    public void clearMethodTest1()
    {
        System.out.println("clear size test, passed");
        
        Queue<Integer> linked = new PriorityQueue();
        
        linked.add(12);
        linked.add(23);
        linked.add(43);
         
        int before = linked.size();        
        linked.clear();        
        int after = linked.size();        
        assertNotSame(before, after);
    }

    
        @Test
    public void clearMethodTest2()
    {
        Queue<Integer> linked =null;
        try
        {
            linked.clear();
        }catch(NullPointerException e)
        {
            System.out.println("NullPointerException has been caught");
//            Factory.appendStr("NullPointerException has been caught, passed\n");
        }
    }
    
    
    @Test
    public void clearMethodTest3()
    {
        Queue<Integer> linked = new PriorityQueue();
        try
        {
            linked.clear();
        }catch (Exception e)
        {           
        }
        System.out.println("list with no content clear test, exception should not be thrown, passed\n");        
    }

    
}
