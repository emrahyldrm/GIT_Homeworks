/**
 * Emrah YILDIRIM 111044056
 * Test List Interface Homework
 */


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testListInterface;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Jason
 */
public class Factory
{
    /**
     * if string is not array or linked method will return ArrayList
     * @param listType
     * @return
     */
    public static List<Integer> factory(String listType)
    {
        String type = listType.toLowerCase();
        switch(type)
        {
            case "array":
                        return new ArrayList<Integer>();
             
            case "linked":
                        return new LinkedList<Integer>();
                
            default:
                    return new ArrayList<>();
        }
    } 
}
